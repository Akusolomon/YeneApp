export class PlaceRepository{
    
}